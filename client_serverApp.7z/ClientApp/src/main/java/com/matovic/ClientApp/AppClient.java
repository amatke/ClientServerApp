package com.matovic.ClientApp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;


public class AppClient {

	static String SERVER_ADDRESS = null;
	static int PORT_NUMBER = 0;
	static String PATH_TO_INPUT_DIR = null;
	
	static Socket socket = null;
	

	public static void main(String[] args) throws UnknownHostException, IOException {
		
		SERVER_ADDRESS = args[0];
		PORT_NUMBER = Integer.parseInt(args[1]);
		PATH_TO_INPUT_DIR = args[2];
		
		System.out.println(SERVER_ADDRESS + ", " + PORT_NUMBER + ", " + PATH_TO_INPUT_DIR);
		
		connectToServer();
		
		sendDataToServer();

		readServerAnswer();

		socket.close();
	}
	
	
	private static void connectToServer() throws UnknownHostException, IOException {
		socket = new Socket(SERVER_ADDRESS, PORT_NUMBER);
		System.out.println("Client started");
	}
	
	private static void sendDataToServer() throws IOException {
		PrintWriter toServer = new PrintWriter(socket.getOutputStream(), true);
		toServer.println(PATH_TO_INPUT_DIR);
	}
	
	private static void readServerAnswer() throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		System.out.println(in.readLine());
	}
	
	
}
