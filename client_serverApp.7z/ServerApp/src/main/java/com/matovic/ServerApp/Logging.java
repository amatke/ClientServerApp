package com.matovic.ServerApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

public class Logging {

	static int size = 0;
	
	static void writeLoggs() throws SQLException {
		createTable();
		insertLoggs();
	}
	
	public static void createTable() throws SQLException {
		
        String sql = "CREATE TABLE IF NOT EXISTS logging (id INTEGER PRIMARY KEY AUTOINCREMENT";
        for (Map.Entry<String, String> log : AppServer.loggs.entrySet()) {
        	
            sql += "," + log.getKey() + " TEXT NOT NULL";
            size++;
		}
        sql += ");";
        
        // SQLite connection string
        String url = "jdbc:sqlite:" + AppServer.PATH_TO_DATABASE;
        // SQL statement for creating a new table
        Connection conn = DriverManager.getConnection(url);
        Statement stmt = conn.createStatement();
        // create a new table
        stmt.execute(sql);
        
        System.err.println(sql);  
	}
	
	
	public static void insertLoggs() throws SQLException {
		
        // SQLite connection string
        String url = "jdbc:sqlite:" + AppServer.PATH_TO_DATABASE;
        Connection conn = DriverManager.getConnection(url);
        Statement stmt = conn.createStatement();
		
	 	String sql2 = "INSERT INTO logging (";
        int k = size;
        for (Map.Entry<String, String> log : AppServer.loggs.entrySet()) {
        	
        	sql2 += log.getKey();
        	if(--k != 0)
        		sql2 += ",";
		}
        sql2 += ") VALUES (";
        
        k = size;
        for (Map.Entry<String, String> log : AppServer.loggs.entrySet()) {
        	sql2 += "'" + log.getValue() + "'";
        	if(--k != 0)
        		sql2 += ",";	
		}
        sql2 += ");";
        stmt.execute(sql2);		
        
        System.err.println(sql2);  	
	}
	
}
