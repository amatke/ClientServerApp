package com.matovic.ServerApp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class AppServer {
	
	static int PORT_NUMBER = 0;
    static String PATH_TO_DATABASE = null;
    static String PATH_TO_OUTPUT_DIR = null;
    
    static Socket socket = null;
    
    static String pathToInputDir = null;

    static HashMap<String, String> map = new HashMap<String, String>();
    
    static String txtData = null;
    static ArrayList<String> excelPodaci = new ArrayList<>();
    static int numRowsExcel = 0;
    
    static String EXCEL_FILE_NAME = null;
    static String TEXT_FILE_NAME = null;
    
    static String DECRYPTED_TEXT_FILE_NAME = null;
    static String DECRYPTED_EXCEL_FILE_NAME = null;
    
    final static String ZIPPED_FILE_NAME = "multiCompressed.zip";
    
    static Map<String, String> loggs = new HashMap<String, String>();
	
	public static void main(String[] args) throws IOException, SQLException {
			
			PORT_NUMBER = Integer.parseInt(args[0]);
	        PATH_TO_DATABASE = args[1];
	        PATH_TO_OUTPUT_DIR = args[2];
	   
	        System.out.println(PORT_NUMBER + ", " + PATH_TO_DATABASE + ", " + PATH_TO_OUTPUT_DIR);
	        
	        startServer();
	        readClientData();
			
			
			
			connectToDB();
			readDB();
	        readTextFile();
	        decryptTEXT();
	        readExcelFile();
	        decryptEXCEL();
	        zipFiles();
	        
	        sendDataToClient();
	        
	        socket.close();
	        
	        Logging.writeLoggs();
		}
	
	private static void startServer() throws IOException {
		ServerSocket ss = new ServerSocket(PORT_NUMBER);
		System.out.println("Server waiting for clients on PORT: " + PORT_NUMBER);
		socket = ss.accept();
		System.out.println("Connection establised!");
	}
	
	private static void readClientData() throws IOException {
		BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		pathToInputDir = in.readLine();
		System.out.println("Client send " + pathToInputDir);
	}
	
	private static void sendDataToClient() throws IOException {
		 PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
	     out.println("Server: Action completed! Files are decrypted and zipped at: " + PATH_TO_OUTPUT_DIR + "\\" + ZIPPED_FILE_NAME );

	}
		
	
   /*** Konekcija kao nasoj bazi koja se nalazi na putanji PATH_TO_DATABASE.
    * 	Vracamo uspostavljenu konekciju. 
 * @throws SQLException */
   private static Connection connectToDB() throws SQLException {
	   //"jdbc:sqlite:/home/projects/product.db";
       String url = "jdbc:sqlite:" + PATH_TO_DATABASE;
       Connection conn = DriverManager.getConnection(url);
       loggs.put("CONNECTION", "Connected to " + url);
       return conn;
   }
   
   
    /*** Citamo iz sqlite baze kljuceve za desifrovanje fajlova.*/ 
	private static void readDB() throws SQLException {

		Connection conn = connectToDB();
		Statement stmt  = conn.createStatement();
        ResultSet rs    = stmt.executeQuery("SELECT * FROM AES_KEYS");
       
	       while (rs.next()) {
	           String key = rs.getString("KEY");
	           String file = rs.getString("FILE");            
	           map.put(file, key);
	       }  
	       //System.out.println("-- MAPA --" + Arrays.asList(map)); // method 1
	       loggs.put("DB_ACTION", "Reading keys for files from DB");
	       System.err.println("Iscitani kljucevi za fajlove iz sqlite baze.");
	}
	
	
	/*** Citamo iz txt fajla i popunjavamo niz txtData sa sifrovanim podacima.*/
    public static void readTextFile() throws IOException {
    	
    	TEXT_FILE_NAME = pathToInputDir + "\\ExternalInput.txt";
    	BufferedReader br = new BufferedReader(new FileReader(new File(TEXT_FILE_NAME)));
    
		String line; 
		while ((line = br.readLine()) != null) {
			 txtData = line;	
		}
		br.close();
		
        //System.out.println("-- txt data --" + txtData); // method 1
		loggs.put("TEXT_ACTION", "Reading input values from ExternalInput.txt");
        System.err.println("ISCITANI text PODACI I INICIJALIZOVAN txtData");	
    }
	
    
/***    Desifrujemo podatke iz niza txtData sa svojim odgovarajucim kljucem za txt fajl.
    Upisujemo desifrovane podatke u novi txt fajl na zadatoj lokaciji.*/
    public static void decryptTEXT() throws IOException {
    	
	   String keyTxt = (String) map.get("ExternalInput.txt");	        
	   String decryptedTxt = Encryptor.decrypt(keyTxt, txtData);
	   //System.out.println("DESIFROVANO: " + decryptedTxt);
	   
	   DECRYPTED_TEXT_FILE_NAME = PATH_TO_OUTPUT_DIR + "\\ExternalOutput.txt";
	   
	   BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(DECRYPTED_TEXT_FILE_NAME), "utf-8"));
	   writer.write(decryptedTxt);
	   writer.close();
	   
       loggs.put("DECRYPTION_TXT", "txt File is decrypted to " + DECRYPTED_TEXT_FILE_NAME);

	   System.err.println("Desifrovan txt fajl");
    }
    
    
    public static void readExcelFile() throws IOException {
    	
        EXCEL_FILE_NAME = pathToInputDir + "\\ExternalInput.xlsx";
    	
        FileInputStream excelFile = new FileInputStream(new File(EXCEL_FILE_NAME));
        Workbook workbook = new XSSFWorkbook(excelFile);
        Sheet datatypeSheet = (Sheet) workbook.getSheetAt(0);
        Iterator<Row> iterator = datatypeSheet.iterator();
        
        numRowsExcel = datatypeSheet.getRow(0).getPhysicalNumberOfCells();

        while (iterator.hasNext()) {

            Row currentRow = iterator.next();
            Iterator<Cell> cellIterator = currentRow.iterator();

            while (cellIterator.hasNext()) {

               Cell currentCell = cellIterator.next();

         	   String keyXlsx = (String) map.get("ExternalInput.xlsx");	        
        	   String decryptedXlsx  = Encryptor.decrypt(keyXlsx, currentCell.getStringCellValue());            	   
        	   excelPodaci.add(decryptedXlsx);
        	   //System.out.println("DESIFROVANO: " + decryptedXlsx );
            }
            //System.out.println();
        }  
        
        loggs.put("EXCEL_ACTION", "Excel file " + EXCEL_FILE_NAME + " is decrypted.");
    }
    
    
    public static void decryptEXCEL() throws IOException {
    	
    	DECRYPTED_EXCEL_FILE_NAME = PATH_TO_OUTPUT_DIR + "/ExternalOutput.xlsx";
    	
    	int columns = excelPodaci.size()/numRowsExcel;
    	
    	XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Datatypes in Java");
        Object[][] datatypes = new Object[columns][numRowsExcel];
        

        for(int i=0; i<numRowsExcel; i++) {
        	datatypes[0][i] = excelPodaci.get(i);
        }
        
        int k=0;
        String data = null;
        for(int i=0; i<excelPodaci.size()/numRowsExcel; i++) {
        	for(int j=0; j<numRowsExcel; j++) {
        		data = excelPodaci.get(k++);
        		if(data.matches("[0-9]+")) 
            		datatypes[i][j] = Integer.parseInt(data);
        	    else 
        			datatypes[i][j] = data;
        	}
        }
        

        int rowNum = 0;
        for (Object[] datatype : datatypes) {
            Row row = sheet.createRow(rowNum++);
            int colNum = 0;
            for (Object field : datatype) {
                Cell cell = row.createCell(colNum++);
                if (field instanceof String) {
                    cell.setCellValue((String) field);
                } else if (field instanceof Integer) {
                    cell.setCellValue((Integer) field);
                }
            }
        }

        
        FileOutputStream outputStream = new FileOutputStream(DECRYPTED_EXCEL_FILE_NAME);
        workbook.write(outputStream);
        workbook.close();
    
        System.err.println("Created new Excel File.");
        
        loggs.put("DECRYPTED_EXCEL", "Excel file is decrypted and ready for zipping.");
    }
    
    
    /*** Zipujemo fajlove koje smo prethodno desifrovali.*/
    public static void zipFiles() throws IOException {
    	
        List<String> srcFiles = Arrays.asList(DECRYPTED_TEXT_FILE_NAME, DECRYPTED_EXCEL_FILE_NAME);
        FileOutputStream fos = new FileOutputStream(PATH_TO_OUTPUT_DIR + "/" + ZIPPED_FILE_NAME);
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        for (String srcFile : srcFiles) {
            File fileToZip = new File(srcFile);
            FileInputStream fis = new FileInputStream(fileToZip);
            ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
            zipOut.putNextEntry(zipEntry);
 
            byte[] bytes = new byte[1024];
            int length;
            while((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            fis.close();
        }
        zipOut.close();
        fos.close();
        
        new File(DECRYPTED_TEXT_FILE_NAME).delete();
        new File(DECRYPTED_EXCEL_FILE_NAME).delete();

        System.err.println("Zipping completed.");
        
        loggs.put("ZIP", "Zipping completed. All files are compressed to " + PATH_TO_OUTPUT_DIR + "\\" + ZIPPED_FILE_NAME);
    }    
    

	
}
